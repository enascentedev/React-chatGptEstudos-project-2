#!/bin/bash

# directory
pwd

# clear
rm -rfv dist

# build
npm run build